package ca.bcit.comp2526.a2a;

public enum Type {
	HERBIVORE,
	PLANT,
	EMPTY
}
