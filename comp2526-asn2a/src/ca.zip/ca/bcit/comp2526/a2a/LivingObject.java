package ca.bcit.comp2526.a2a;

import java.util.ArrayList;
import java.awt.Color;

/**
 * Abstract class LivingObject.
 * @author jennyly
 * @version 1.0
 */
public abstract class LivingObject extends Holdable {
     private int dayCountDown;
     private Cell location;

     /**
      * Constructor.
      * @param location cell
      */
     public LivingObject(Cell location) {
          super(location);
          this.location = location;
     }
     
     /**
      * Abstract init().
      */
     public abstract void init();
     
     /**
      * Abstract setCell.
      * @param locat as Cell
      */
     public void setCell(Cell locat) {
    	 this.location = locat;
    	 locat.setHoldable(this);
    	 init();
     }
     
     
     
     /**
      * Abstract die().
      */
     public void die() {
    	 if (dayCountDown == 0) {
    		 new Holdable(location).init();
    	 }
     }
     
     public void eat() {
    	 int index;
    	 Cell selectedCell;
    	 if (getFoodArray() != null) {
    		 dayCountDown = getMaxHunger();
    		 if (getFoodCount() > 0){
        		 index = RandomGenerator.nextNumber(getFoodCount());
        		 selectedCell = getFoodArray().get(index);
        	 
    	    	 if (location.hasNotMove()) {
    	    		 new Holdable(location).init();
    	    		 this.setCell(selectedCell);
    	    
    	    		 
    	    		 location.setMoved(false);
    	    	 }
        	 } else {
        		 index = RandomGenerator.nextNumber(location.getEmptyCount());
        		 selectedCell = location.getEmptyArray().get(index);
        		 
        		 if(location.hasNotMove()) {
        			 dayCountDown--;
        			 new Holdable(location).init();
        			 this.setCell(selectedCell);
        		
        			 
        			 location.setMoved(false);
        		 }
        	 }
    	 }
     }
     
     public void reproduce() {
    	 if (getSelfCount() >= getMinMates() && location.getEmptyCount() >= getMinEmpty()
    			 && getFoodCount() >= getMinFood() && dayCountDown != 0) {
    		 int index = RandomGenerator.nextNumber(location.getEmptyCount());
    		 Cell selectedCell = location.getEmptyArray().get(index);
    		 createLife(selectedCell).init();
    	 }
     }
     
     public abstract ArrayList<Cell> getSelfArray();
     
     public abstract int getSelfCount();
     
     public abstract LivingObject createLife(Cell locat);
     /**
      * Abstract move().
      */
     public void move() {
    	 //this.die();
    	 this.eat();
    	 //this.reproduce();
    	 
     }
     
     
     
     public abstract ArrayList<Cell> getFoodArray();
     public abstract int getFoodCount();
    
     /**
      * Gets daysleft.
      * @return the dayCountDown
      */
     public int getDayCountDown() {
          return dayCountDown;
     }
     
     /**
      * Gets location.
      * @return location
      */
     public Cell getLocation() {
          return location;
     }
     
   
     
     public abstract int getMinEmpty();
     
     public abstract int getMaxHunger();
     
     public abstract int getMinFood();
     
     public abstract int getMinMates();

}
