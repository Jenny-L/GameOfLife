package ca.bcit.comp2526.a2a;

import java.awt.Color;
import java.util.ArrayList;

public class Omnivore extends LivingObject {
	 private static final int MIN_EMPTY = 3;
     private static final int MAX_HUNGER = 2;
     private static final int NUM_MATES = 1;
     private static final int FOOD_COUNT = 3;
     private int dayCountDown;
     private Type type;
     private Cell location;
     private ArrayList<Cell> food = new ArrayList<Cell>();

	/**
     * Constructor.
     * @param location as Cell
     */
    public Omnivore(Cell location) {
  
         super(location);
         this.location = location;
         type = Type.OMNIVORE;
         dayCountDown = MAX_HUNGER;

    }
    
    public void init() {
    	location.getJPanel().setBackground(Color.blue);
    }

    public LivingObject createLife(Cell locat) {
   	 return new Omnivore(locat);
    }
    
    public ArrayList<Cell> getSelfArray() {
    	return location.getOmniArray();
    }
    
    public int getSelfCount() {
   	 	return location.getOmniCount();
    }
    
    public ArrayList<Cell> getFoodArray() {
    	
    	for (Cell cell:location.getPlantArray()) {
    		food.add(cell);
    	}
    	for (Cell cell:location.getHerbArray()){
    		food.add(cell);
    	}
    	return food;
    }
    
    public int getFoodCount() {
    	return location.getPlantCount() + location.getHerbCount();
    }
	
	 public int getMinEmpty() {
    	 return MIN_EMPTY;
     }
     
     public int getMaxHunger() {
 		return MAX_HUNGER;
 	}
     
    public int getMinMates() {
    	return NUM_MATES;
    }
    
    public int getMinFood() {
    	return FOOD_COUNT;
    }
}
