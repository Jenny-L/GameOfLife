package ca.bcit.comp2526.a2a;

import java.awt.Color;
import java.util.ArrayList;

/**
 * Plant.
 * @author jennyly
 * @version 1.0
 */
public class Plant extends LivingObject {
     private static final int MIN_EMPTY = 3;
     private static final int MAX_HUNGER = -1; //does not apply to plant
     private static final int NUM_MATES = 2;
     private static final int FOOD_COUNT = -1; // does not apply to plant


     /**
      * Constructor.
      * @param location as Cell
      */
     public Plant(Cell location) {
          super(location, Type.PLANT);
          // TODO Auto-generated constructor stub
     }

     /**
      * Sets background to green.
      */
     public void init() {
    	 getLocation().getJPanel().setBackground(Color.green);
     }
     
  
//     /**
//      * Adds an additional plant if at least 2 neighbours are plants
//      * and if there is at least 3 empty spaces.
//      */
//     public void move() {
//          if (location.getPlantCount() >= NUM_MATES 
//                    && location.getEmptyCount() >= MIN_EMPTY) {
//               int index = RandomGenerator.nextNumber(location.getEmptyCount());
//               Cell selectedCell = location.getEmptyArray().get(index);
//               new Plant(selectedCell).init();
//          }
//     }
//     
//     /**
//      * No plant die method is needed.
//      */
//     public void die() {
//          
//     }
     public ArrayList<Cell> getSelfArray() {
    	 return getLocation().getPlantArray();
     }
     
     public int getSelfCount() {
    	 return getLocation().getPlantCount();
     }
     
     public ArrayList<Cell> getFoodArray() {
      	return null;

      }
      
      public int getFoodCount() {
      	return -1;
      }
//     
     public LivingObject createLife(Cell locat) {
    	 return new Plant(locat);
     }
     
     public int getMinEmpty() {
    	 return MIN_EMPTY;
     }
     
     public int getMaxHunger() {
 		return MAX_HUNGER;
 	}
     
    public int getMinMates() {
    	return NUM_MATES;
    }
     
    public int getMinFood() {
    	return FOOD_COUNT;
    }
}
