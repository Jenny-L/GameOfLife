package ca.bcit.comp2526.a2a;

import java.util.ArrayList;
import java.awt.Color;

/**
 * Abstract class LivingObject.
 * @author jennyly
 * @version 1.0
 */
public abstract class LivingObject extends Holdable {
     private int dayCountDown;

     /**
      * Constructor.
      * @param location cell
      */
     public LivingObject(Cell location, Type type) {
          super(location, type);
          this.setDayCountDown();
     }
     
     /**
      * Abstract init().
      */
     public abstract void init();
     
     /**
      * Abstract setCell.
      * @param locat as Cell
      */
     public void setCell(Cell locat) {
    	 super.setLocation(locat);
    	 locat.setHoldable(this);
    	 init();
     }
     
     
     
     /**
      * Abstract die().
      */
     public void die() {
    	 if (dayCountDown == 0) {
    		 new Holdable(getLocation()).init();
    	 }
     }
     
     public void eat() {
    	 int index;
    	 Cell selectedCell;
    	 if (getFoodArray() != null) {
    		 
    		 if (getFoodCount() > 0){
    			 dayCountDown = getMaxHunger();
        		 index = RandomGenerator.nextNumber(getFoodCount());
        		 selectedCell = getFoodArray().get(index);
        	 
    	    	 if (getLocation().hasNotMove()) {
    	    		 new Holdable(getLocation()).init();
    	    		 this.setCell(selectedCell);
    	    		
    	    
    	    		 
    	    		 getLocation().setMoved(false);
    	    	 }
        	 } else if (getLocation().getEmptyCount() != 0) {
        		 index = RandomGenerator.nextNumber(getLocation().getEmptyCount());
        		 selectedCell = getLocation().getEmptyArray().get(index);
        		 
        		 if(getLocation().hasNotMove()) {
        			 dayCountDown--;
        			 new Holdable(getLocation()).init();
        			 this.setCell(selectedCell);
        		
        			 
        			 getLocation().setMoved(false);
        		 }
        	 } else {
        		 dayCountDown--;
        		 getLocation().setMoved(false);
        	 }
    	 }
    	 
     }
     
     public void reproduce() {
    	 //System.out.println(getType() + Integer.toString(getLocation().getX()) + " " + Integer.toString(getLocation().getY()) + "numberMates:" + 
    	 if (getSelfCount() >= getMinMates() && getLocation().getEmptyCount() >= getMinEmpty()
    			 && getFoodCount() >= getMinFood() && dayCountDown != 0) {
    		 int index = RandomGenerator.nextNumber(getLocation().getEmptyCount());
    		 Cell selectedCell = getLocation().getEmptyArray().get(index);
    		 //System.out.println(selectedCell.getX() + "," + selectedCell.getY() +"numberMates:" + getSelfCount() + ", " + "emptyCells:" + getLocation().getEmptyCount() + ", " + "foodCount" + getFoodCount() );
    		 createLife(selectedCell).init();
    		 
    	 }
    	 
     }
     
     public abstract ArrayList<Cell> getSelfArray();
     
     public abstract int getSelfCount();
     
     public abstract LivingObject createLife(Cell locat);
     /**
      * Abstract move().
      */
     public void move() {
    	 this.eat();
    	 
     }
     
     
     
     public abstract ArrayList<Cell> getFoodArray();
     public abstract int getFoodCount();
    
     /**
      * Gets daysleft.
      * @return the dayCountDown
      */
     public int getDayCountDown() {
          return dayCountDown;
     }
     
     private void setDayCountDown() {
    	 dayCountDown = getMaxHunger();
     }
     
     /**
      * Gets location.
      * @return location
      */
     public Cell getLocation() {
          return super.getLocation();
     }
     
   
     
     public abstract int getMinEmpty();
     
     public abstract int getMaxHunger();
     
     public abstract int getMinFood();
     
     public abstract int getMinMates();

}
