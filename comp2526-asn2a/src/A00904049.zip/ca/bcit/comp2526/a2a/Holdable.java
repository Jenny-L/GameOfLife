package ca.bcit.comp2526.a2a;

import java.awt.Color;
import java.awt.Panel;

import javax.swing.JPanel;

/**
 * Holdable.
 * @author jennyly
 * @version 1.0
 */
public class Holdable {
     private Cell location;
     private Type type;
     //private Holdable holdable;
     //private boolean moved;
     
     /**
      * Constructor.
      * @param location as Cell
      */
     public Holdable(Cell location, Type type) {
          this.location = location;
          location.setHoldable(this);
          this.type = type;
     }
     

     public Holdable(Cell location) {
          this.location = location;
          location.setHoldable(this);
          type = Type.EMPTY;
     }
     
     
     /**
      * Change background color to white.
      */
     public void init() {
          location.getJPanel().setBackground(Color.white);
     }
     
     
     /**
      * Gets location.
      * @return the location
      */
     public Cell getLocation() {
          return location;
     }
     
     public void setLocation(Cell locat) {
    	 location = locat;
     }
     
     /**
      * Gets cell type.
      * @param locat as Cell
      * @return type as Type
      */
     public Type getType() {
          return type;
     }
     
     /**
      * Does not move.
      */
     public void move() {
     }
     
     public void reproduce() {
    	 
     }
     
     /**
      * Does not die.
      */
     public void die() {
          
     }
     
}

